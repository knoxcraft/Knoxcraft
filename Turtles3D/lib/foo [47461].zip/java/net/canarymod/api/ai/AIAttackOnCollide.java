package net.canarymod.api.ai;

/**
 * @author Aaron
 */
public interface AIAttackOnCollide extends AIBase {

}
