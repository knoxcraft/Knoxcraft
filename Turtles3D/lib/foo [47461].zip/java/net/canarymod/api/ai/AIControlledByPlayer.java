package net.canarymod.api.ai;

/**
 * @author Aaron
 */
public interface AIControlledByPlayer extends AIBase {

}
