package net.canarymod.api.ai;

/**
 * @author Aaron
 */
public interface AINearestAttackableTarget extends AIBase {

}
