package net.canarymod.api.ai;

/**
 * @author Aaron
 */
public interface AILookAtVillager extends AIBase {

}
