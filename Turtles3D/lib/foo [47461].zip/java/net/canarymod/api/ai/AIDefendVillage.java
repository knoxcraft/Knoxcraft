package net.canarymod.api.ai;

/**
 * @author Aaron
 */
public interface AIDefendVillage extends AIBase {

}
