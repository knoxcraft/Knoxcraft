package net.canarymod.api.ai;

/**
 * @author Aaron
 */
public interface AIEatGrass extends AIBase {

}
