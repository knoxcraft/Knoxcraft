package net.canarymod.api.ai;

/**
 * @author Aaron
 */
public interface AIMoveTowardsRestriction extends AIBase {

}
