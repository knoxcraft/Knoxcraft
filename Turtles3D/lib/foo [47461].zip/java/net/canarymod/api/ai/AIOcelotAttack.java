package net.canarymod.api.ai;

/**
 * @author Aaron
 */
public interface AIOcelotAttack extends AIBase {

}
