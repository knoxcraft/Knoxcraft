package net.canarymod.api.entity.effect;

import net.canarymod.api.entity.Entity;

/**
 * Weather Effect Wrapper Interface
 *
 * @author Jason (darkdiplomat)
 */
public interface WeatherEffect extends Entity {
}
