package net.canarymod;

/**
 * Not Yet Implemented
 *
 * @author Jason Jones (darkdiplomat)
 */
public class NotYetImplementedException extends UnsupportedOperationException {

    public NotYetImplementedException() {

    }

    public NotYetImplementedException(String msg) {
        super(msg);
    }
}
