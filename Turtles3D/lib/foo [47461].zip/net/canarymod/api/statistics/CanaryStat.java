package net.canarymod.api.statistics;

import net.minecraft.stats.StatBase;

/**
 * Stat wrapper implementation
 *
 * @author Jason (darkdiplomat)
 */
public class CanaryStat implements Stat {
    private StatBase statbase;

    /**
     * Constructs a new StatBase wrapper
     *
     * @param statbase
     *         the StatBase to wrap
     */
    public CanaryStat(StatBase statbase) {
        this.statbase = statbase;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getId() {
        return getHandle().e;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getName() {
        return statbase.toString();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isIndependent() {
        return statbase.f;
    }

    public StatBase getHandle() {
        return statbase;
    }
}
