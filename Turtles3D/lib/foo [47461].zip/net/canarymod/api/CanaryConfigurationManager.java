package net.canarymod.api;

import net.canarymod.Canary;
import net.canarymod.api.entity.living.humanoid.CanaryPlayer;
import net.canarymod.api.entity.living.humanoid.Player;
import net.canarymod.api.packet.CanaryPacket;
import net.canarymod.api.packet.Packet;
import net.canarymod.api.world.DimensionType;
import net.canarymod.api.world.World;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.management.ServerConfigurationManager;

import java.util.ArrayList;
import java.util.List;

public class CanaryConfigurationManager implements ConfigurationManager {

    ServerConfigurationManager manager;

    public CanaryConfigurationManager(ServerConfigurationManager man) {
        manager = man;
    }

    public ServerConfigurationManager getHandle() {
        return manager;
    }

    @Override
    public void sendPacketToAllInWorld(String world, Packet packet) {
        for (Object p : manager.e) {
            if (!(p instanceof EntityPlayerMP)) {
                continue;
            }
            if (((EntityPlayerMP) p).getCanaryWorld().getName().equals(world)) {
                manager.sendPacketToPlayer(((EntityPlayerMP) p).getPlayer(), (CanaryPacket) packet);
            }
        }

    }

    @Override
    public int getNumPlayersOnline() {
        return manager.e.size();
    }

    @Override
    public Player getPlayerByName(String name) {
        EntityPlayerMP player = manager.a(name);
        return player == null ? null : player.getPlayer();
    }

    @Override
    public List<Player> getAllPlayers() {
        List<Player> players = new ArrayList<Player>(manager.e.size());

        for (Object p : manager.e) {
            if (!(p instanceof EntityPlayerMP)) {
                continue;
            }
            players.add(((EntityPlayerMP) p).getPlayer());
        }
        return players;
    }

    @Override
    public int getMaxPlayers() {
        return manager.p();
    }

    @Override
    public void markBlockNeedsUpdate(int x, int y, int z, DimensionType dimension, String world) {
        Canary.getServer().getWorldManager().getWorld(world, dimension, true).getPlayerManager().markBlockNeedsUpdate(x, y, z);

    }

    @Override
    public void switchDimension(Player player, World world, boolean createPortal) {
        // Respawn
        manager.a(((CanaryPlayer) player).getHandle(), world.getType().getId(), true, world.getSpawnLocation());
    }
}
