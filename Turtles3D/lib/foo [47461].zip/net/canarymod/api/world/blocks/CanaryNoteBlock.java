package net.canarymod.api.world.blocks;

import net.canarymod.api.world.CanaryWorld;
import net.minecraft.block.material.Material;
import net.minecraft.tileentity.TileEntityNote;
import net.minecraft.util.BlockPos;

/**
 * NoteBlock wrapper implementation
 *
 * @author Jason (darkdiplomat)
 */
public class CanaryNoteBlock extends CanaryTileEntity implements NoteBlock {

    /**
     * Constructs a new wrapper for TileEntityChest
     *
     * @param tileentity
     *         the TileEntityChest to be wrapped
     */
    public CanaryNoteBlock(TileEntityNote tileentity) {
        super(tileentity);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public byte getInstrument() {
        Material material = ((CanaryBlock)getWorld().getBlockAt(getX(), getY() - 1, getZ())).getBlock().r();
        byte instrument = 0;

        if (material == Material.e) {
            instrument = 1;
        }

        if (material == Material.p) {
            instrument = 2;
        }

        if (material == Material.r) {
            instrument = 3;
        }

        if (material == Material.d) {
            instrument = 4;
        }

        return instrument;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public byte getNote() {
        return getTileEntity().a;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void play() {
        getTileEntity().a(tileentity.z(), new BlockPos(getX(), getY(), getZ()));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setNote(byte note) {
        if (note < 0) {
            note = 0;
        }
        if (note > 24) {
            note = 24;
        }

        getTileEntity().a = note;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public TileEntityNote getTileEntity() {
        return (TileEntityNote) tileentity;
    }
}
