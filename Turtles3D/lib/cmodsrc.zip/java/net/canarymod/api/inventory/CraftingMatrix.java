package net.canarymod.api.inventory;

/**
 * Crafting Matrix sharer interface
 * This interface is so Workbench and PlayerCraftingMatrix can be sent the same
 *
 * @author Jason (darkdiplomat)
 */
public interface CraftingMatrix extends Inventory {
}
