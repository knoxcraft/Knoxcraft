package net.canarymod.api.inventory;

/**
 * The Player's crafting space
 *
 * @author Jason (darkdiplomat)
 */
public interface PlayerCraftingMatrix extends CraftingMatrix {
}
