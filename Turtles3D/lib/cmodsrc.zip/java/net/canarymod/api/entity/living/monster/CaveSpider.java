package net.canarymod.api.entity.living.monster;

/**
 * CaveSpider Wrapper
 *
 * @author Jason (darkdiplomat)
 */
public interface CaveSpider extends Spider {// Nothing more required
}
