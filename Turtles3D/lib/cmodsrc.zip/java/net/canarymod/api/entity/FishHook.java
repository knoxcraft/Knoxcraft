package net.canarymod.api.entity;

/**
 * Fish Hook wrapper
 *
 * @author Jason (darkdiplomat)
 */
public interface FishHook extends Entity {
    // I got nothing for this right now
}
