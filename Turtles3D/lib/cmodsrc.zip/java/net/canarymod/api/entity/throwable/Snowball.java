package net.canarymod.api.entity.throwable;

/**
 * Snowball wrapper
 *
 * @author Jason (darkdiplomat)
 */
public interface Snowball extends EntityThrowable {
}
