package net.canarymod.api.entity.living.monster;

/**
 * LavaSlime wrapper
 *
 * @author Jason (darkdiplomat)
 */
public interface MagmaCube extends Slime {
}
