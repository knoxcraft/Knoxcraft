package net.canarymod.api.entity.living.animal;

/**
 * Mooshroom wrapper
 *
 * @author Jason (darkdiplomat)
 */
public interface Mooshroom extends Cow {
}
