package net.canarymod.api.entity.vehicle;

import net.canarymod.api.inventory.Inventory;

/**
 * ContainerMinecart wrapper
 *
 * @author Somners
 */
public interface ContainerMinecart extends Minecart, Inventory {

}
