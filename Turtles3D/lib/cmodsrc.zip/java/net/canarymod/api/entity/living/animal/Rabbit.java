package net.canarymod.api.entity.living.animal;

/**
 * Rabbit wrapper
 *
 * @author Jason Jones (darkdiplomat)
 */
public interface Rabbit extends EntityAnimal {
}
