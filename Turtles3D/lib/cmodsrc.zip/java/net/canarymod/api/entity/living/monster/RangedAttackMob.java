package net.canarymod.api.entity.living.monster;

/**
 * Interface for distinguishing which mobs have ranged attack abilities.
 *
 * @author Aaron
 */
public interface RangedAttackMob {

}
