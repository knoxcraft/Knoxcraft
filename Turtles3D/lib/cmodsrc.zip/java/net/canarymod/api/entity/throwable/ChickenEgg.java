package net.canarymod.api.entity.throwable;

/**
 * Chicken Egg wrapper
 *
 * @author Jason (darkdiplomat)
 */
public interface ChickenEgg extends EntityThrowable {
}
