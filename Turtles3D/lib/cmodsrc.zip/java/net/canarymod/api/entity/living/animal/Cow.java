package net.canarymod.api.entity.living.animal;

import net.canarymod.api.entity.living.Ageable;

/**
 * Cow Wrapper
 *
 * @author Jason (darkdiplomat)
 */
public interface Cow extends EntityAnimal, Ageable {
}
