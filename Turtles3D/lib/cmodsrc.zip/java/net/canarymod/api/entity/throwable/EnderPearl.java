package net.canarymod.api.entity.throwable;

/**
 * EnderPerl wrapper
 *
 * @author Jason (darkdiplomat)
 */
public interface EnderPearl extends EntityThrowable {
}
