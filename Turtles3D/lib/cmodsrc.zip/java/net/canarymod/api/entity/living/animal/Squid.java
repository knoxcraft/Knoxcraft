package net.canarymod.api.entity.living.animal;

/**
 * Squid wrapper
 *
 * @author Jason (darkdiplomat)
 */
public interface Squid extends EntityAnimal {
}
