package net.canarymod.api.entity.living;

/**
 * Interface for ambient creatures.
 *
 * @author Larry1123
 */
public interface AmbientCreature {
}
