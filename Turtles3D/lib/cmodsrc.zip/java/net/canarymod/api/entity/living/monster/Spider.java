package net.canarymod.api.entity.living.monster;

/**
 * Spider wrapper
 *
 * @author Jason (darkdiplomat)
 */
public interface Spider extends EntityMob {
}
