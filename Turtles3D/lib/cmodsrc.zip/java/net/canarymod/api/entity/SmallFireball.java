package net.canarymod.api.entity;

/**
 * Small Fireball Wrapper (FireCharge)
 *
 * @author Jason (darkdiplomat)
 */
public interface SmallFireball extends Fireball {
}
