package net.canarymod.api.entity.vehicle;

import net.canarymod.api.CommandBlockLogic;

/**
 * Command Block Minecart wrapper
 *
 * @author Jason (darkdiplomat)
 */
public interface CommandBlockMinecart extends Minecart, CommandBlockLogic {
    //nothing right now
}
