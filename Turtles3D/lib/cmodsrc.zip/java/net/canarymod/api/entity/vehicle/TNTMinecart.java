package net.canarymod.api.entity.vehicle;

import net.canarymod.api.entity.Explosive;

/**
 * TrinitrotolueneMinecart wrapper
 *
 * @author Jason (darkdiplomat)
 */
public interface TNTMinecart extends Minecart, Explosive {
}
