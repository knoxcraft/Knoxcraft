package net.canarymod.api.entity.hanging;

/**
 * LeashKnot wrapper interface
 *
 * @author Jason (darkdiplomat)
 */
public interface LeashKnot extends HangingEntity {
}
