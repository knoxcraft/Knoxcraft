package net.canarymod.api.entity;

/**
 * Large Fireball Wrapper (Ghast Fireball)
 *
 * @author Jason (darkdiplomat)
 */
public interface LargeFireball extends Fireball, Explosive {
}
