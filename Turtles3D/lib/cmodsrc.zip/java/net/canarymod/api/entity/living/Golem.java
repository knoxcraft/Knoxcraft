package net.canarymod.api.entity.living;

/**
 * Golem wrapper
 *
 * @author Jason (darkdiplomat)
 */
public interface Golem extends EntityLiving {
}
