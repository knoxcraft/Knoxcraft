package net.canarymod.api.entity.throwable;

/**
 * XPBottle wrapper
 *
 * @author Jason (darkdiplomat)
 */
public interface XPBottle extends EntityThrowable {
}
