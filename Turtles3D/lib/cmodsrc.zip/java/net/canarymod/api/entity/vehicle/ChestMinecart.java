package net.canarymod.api.entity.vehicle;

/**
 * ChestMinecraft wrapper
 *
 * @author Jason (darkdiplomat)
 */
public interface ChestMinecart extends ContainerMinecart {

}
