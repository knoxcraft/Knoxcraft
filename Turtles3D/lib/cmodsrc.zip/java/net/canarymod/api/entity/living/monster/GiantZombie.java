package net.canarymod.api.entity.living.monster;

/**
 * Giant Zombie wrapper
 *
 * @author Jason (darkdiplomat)
 */
public interface GiantZombie extends EntityMob {
}
