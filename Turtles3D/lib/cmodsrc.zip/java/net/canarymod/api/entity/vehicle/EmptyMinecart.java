package net.canarymod.api.entity.vehicle;

/**
 * EmptyMinecart (Ridable) wrapper
 *
 * @author Jason (darkdiplomat)
 */
public interface EmptyMinecart extends Minecart {

}
