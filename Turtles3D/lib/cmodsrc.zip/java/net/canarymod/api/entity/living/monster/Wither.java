package net.canarymod.api.entity.living.monster;

/**
 * Wither wrapper
 *
 * @author Jason (darkdiplomat)
 */
public interface Wither extends EntityMob, RangedAttackMob {
}
