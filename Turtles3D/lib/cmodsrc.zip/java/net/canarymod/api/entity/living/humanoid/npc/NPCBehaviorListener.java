package net.canarymod.api.entity.living.humanoid.npc;

/**
 * A newer and updated NPC Behavior listening
 *
 * @author Jason (darkdiplomat)
 */
public interface NPCBehaviorListener {
    /*
    Example code:

    @NPCBehavior
    private final void someNameforanUpdateMethod(Update update){
        // do stuff
    }

    */
}
