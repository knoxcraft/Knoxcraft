package net.canarymod.api.scoreboard;

/**
 * Wrapper Interface for Health Score Criteria
 *
 * @author Somners
 */
public interface ScoreHealthCriteria extends ScoreDummyCriteria {

}
