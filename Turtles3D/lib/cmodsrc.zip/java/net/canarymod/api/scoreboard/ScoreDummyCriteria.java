package net.canarymod.api.scoreboard;

/**
 * @author Somners
 */
public interface ScoreDummyCriteria extends ScoreObjectiveCriteria {

}
