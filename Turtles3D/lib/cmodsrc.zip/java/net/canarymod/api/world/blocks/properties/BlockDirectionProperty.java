package net.canarymod.api.world.blocks.properties;

/**
 * PropertyDirection wrapper
 *
 * @author Jason Jones (darkdiplomat)
 */
public interface BlockDirectionProperty extends BlockEnumProperty {
}
