package net.canarymod.api.world.blocks;

/**
 * Dropper wrapper
 *
 * @author Jason (darkdiplomat)
 */
public interface Dropper extends Dispenser {
}
