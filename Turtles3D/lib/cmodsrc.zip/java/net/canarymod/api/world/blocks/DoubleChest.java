package net.canarymod.api.world.blocks;

/**
 * DoubleChest interface
 *
 * @author Chris (damagefilter)
 */
public interface DoubleChest extends Chest {
}
