package net.canarymod.api.world.blocks;

/**
 * BrewingStand interface
 *
 * @author Jason (darkdiplomat)
 */
public interface BrewingStand extends LockableTileEntity {
}
