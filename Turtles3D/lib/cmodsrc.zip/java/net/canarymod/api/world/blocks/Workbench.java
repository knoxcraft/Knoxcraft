package net.canarymod.api.world.blocks;

import net.canarymod.api.inventory.CraftingMatrix;

/**
 * Workbench interface
 *
 * @author Jason (darkdiplomat)
 */
public interface Workbench extends TileEntity, CraftingMatrix {
}
