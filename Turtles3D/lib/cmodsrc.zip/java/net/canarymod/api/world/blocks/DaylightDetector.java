package net.canarymod.api.world.blocks;

/**
 * DaylightDetector wrapper
 *
 * @author Jason (darkdiplomat)
 */
public interface DaylightDetector extends TileEntity {
}
