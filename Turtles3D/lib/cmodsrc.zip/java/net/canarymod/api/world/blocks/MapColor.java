package net.canarymod.api.world.blocks;

/**
 * Map Color wrapper
 *
 * @author Jason (darkdiplomat)
 */
public interface MapColor {

    int getIndex();

    int getValue();
}
