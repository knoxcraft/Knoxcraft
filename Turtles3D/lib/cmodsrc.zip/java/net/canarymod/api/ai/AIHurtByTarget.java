package net.canarymod.api.ai;

/**
 * @author Aaron
 */
public interface AIHurtByTarget extends AIBase {

}
