package net.canarymod.api.ai;

/**
 * @author Aaron
 */
public interface AISwimming extends AIBase {

}
