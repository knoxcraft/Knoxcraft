package net.canarymod.channels;

/**
 * @author Somners
 */
public class CustomPayloadChannelException extends Exception {

    private static final long serialVersionUID = 5665326099228188167L;

    public CustomPayloadChannelException(String message) {
        super(message);
    }
}
