package net.canarymod.commandsys;

/**
 * Listener interface to mark a class a command class.
 *
 * @author Chris (damagefilter)
 */
public interface CommandListener {

}
